package com.example.myapplication;

public class CityData {
    public static String[] cities = {
            "New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia",
            "San Antonio", "San Diego", "Dallas", "San Jose", "Austin", "Jacksonville",
            "San Francisco", "Indianapolis", "Columbus", "Fort Worth", "Charlotte",
            "Seattle", "Denver", "Washington", "Boston", "El Paso", "Detroit", "Nashville",
            "Portland", "Memphis", "Oklahoma City", "Las Vegas", "Louisville", "Baltimore"
            // Add more cities as needed
    };
}
